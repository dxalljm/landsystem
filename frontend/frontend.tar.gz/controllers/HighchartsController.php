<?php
namespace frontend\controllers;

use yii;

class HighchartsController extends Controller
{
	public function actionHighchartsindex()
	{
		
	}
	
	public function showHighcharts()
	{
		
	}
}