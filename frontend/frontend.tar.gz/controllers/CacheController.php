<?php
namespace console\controllers;
use yii\console\Controller;
use app\models\Cache;
class CacheController extends Controller
{
	public function actionCachetext()
	{
		echo 'hello';
// 		$model = new Cache();
// 		$model->content = 'text';
// 		$model->save();
	}
}