<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%bank_account}}".
 *
 * @property integer $id
 * @property string $accountnumber
 * @property integer $farmer_id
 * @property string $bank
 */
class Highcharts extends \yii\db\ActiveRecord
{
   public static function showHighcharts($data)
   {
   		
   }
}
